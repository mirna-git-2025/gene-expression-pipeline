# ============================================================
# PROJECT TITLE:
# Biofilm, virulence factors, CSH analysis, sequence alignment,
# and phylogenetic tree of Candida isolates
# ============================================================


# ============================================================
# 1. IMPORT LIBRARIES
# Purpose:
# These libraries allow us to read the CSV file, perform calculations,
# create plots, read FASTA sequences, align sequences, and build a tree.
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from Bio import SeqIO
from Bio.Align import MultipleSeqAlignment
from Bio.Phylo.TreeConstruction import DistanceCalculator, DistanceTreeConstructor
from Bio import Phylo


# ============================================================
# 2. LOAD THE CSV FILE
# Purpose:
# We load the table containing biofilm, metabolic activity,
# CSH percentage, virulence genes, and resistance mutation data.
# ============================================================

df = pd.read_csv("data.csv", header=None)

# Split by comma
df = df[0].str.split(",", expand=True)

# Set first row as column names
df.columns = df.iloc[0]
df = df[1:].reset_index(drop=True)

# Clean spaces
df.columns = df.columns.str.strip()

print(df.head())


# ============================================================
# 3. CONVERT COLUMNS TO NUMERIC VALUES
# Purpose:
# Python must understand these columns as numbers before making
# calculations and plots.
# ============================================================

numeric_columns = [
    "biofilm_OD570",
    "metabolic_OD490",
    "CSH_percent",
    "ALS3",
    "HWP1",
    "ERG11_mutation"
]

for col in numeric_columns:
    df[col] = df[col].astype(float)


# ============================================================
# 4. BIOFILM CLASSIFICATION
# Purpose:
# We classify isolates as strong or weak biofilm producers.
# Here, OD570 > 1 is considered strong biofilm production.
# ============================================================

df["biofilm_level"] = np.where(
    df["biofilm_OD570"] > 1,
    "Strong",
    "Weak"
)

print("\n=== BIOFILM CLASSIFICATION ===")
print(df[["species", "biofilm_OD570", "biofilm_level"]])


# ============================================================
# 5. VIRULENCE SCORE CALCULATION
# Purpose:
# We calculate a simple virulence score based on the presence
# of ALS3 and HWP1 genes.
# 1 = gene present, 0 = gene absent
# ============================================================

df["virulence_score"] = df[["ALS3", "HWP1"]].sum(axis=1)

print("\n=== VIRULENCE SCORE ===")
print(df[["species", "ALS3", "HWP1", "virulence_score"]])


# ============================================================
# 6. BIOFILM / CSH RATIO
# Purpose:
# This calculation helps compare biofilm formation with cell
# surface hydrophobicity.
# It can show whether isolates with higher CSH also form more biofilm.
# ============================================================

df["biofilm_CSH_ratio"] = df["biofilm_OD570"] / df["CSH_percent"]

print("\n=== BIOFILM / CSH RATIO ===")
print(df[["species", "biofilm_OD570", "CSH_percent", "biofilm_CSH_ratio"]])


# ============================================================
# 7. MEAN VALUES BY SPECIES GROUP
# Purpose:
# Since we have many isolates, we group them by species name
# without isolate number and calculate the mean.
# This gives a clearer biological comparison between species.
# ============================================================

df["species_group"] = df["species"].str.replace(r"_\d+$", "", regex=True)

mean_by_species = df.groupby("species_group")[
    ["biofilm_OD570", "metabolic_OD490", "CSH_percent", "virulence_score"]
].mean()

print("\n=== MEAN VALUES BY SPECIES ===")
print(mean_by_species)


# ============================================================
# 8. LOAD FASTA SEQUENCES
# Purpose:
# We read DNA sequences from the FASTA file for sequence comparison.
# These sequences will be used for alignment and phylogenetic analysis.
# ============================================================

records = list(SeqIO.parse("projectsequences.fasta", "fasta"))

print("\n=== FASTA SEQUENCES ===")
for record in records:
    print(record.id, record.seq)


# ============================================================
# 9. MULTIPLE SEQUENCE ALIGNMENT
# Purpose:
# We create an alignment object from sequences of the same length.
# Alignment allows comparison between species at the DNA sequence level.
# ============================================================

alignment = MultipleSeqAlignment(records)

print("\n=== ALIGNMENT ===")
print(alignment)


# ============================================================
# 10. DISTANCE MATRIX
# Purpose:
# The distance matrix calculates genetic differences between sequences.
# A smaller distance means the sequences are more similar.
# ============================================================

calculator = DistanceCalculator("identity")
distance_matrix = calculator.get_distance(alignment)

print("\n=== DISTANCE MATRIX ===")
print(distance_matrix)


# ============================================================
# 11. PHYLOGENETIC TREE
# Purpose:
# We build a Neighbor-Joining tree to visualize genetic relationships
# between Candida species.
# ============================================================

constructor = DistanceTreeConstructor()
tree = constructor.nj(distance_matrix)

print("\n=== PHYLOGENETIC TREE ASCII ===")
Phylo.draw_ascii(tree)


# ============================================================
# 12. GRAPHICAL PHYLOGENETIC TREE
# Purpose:
# This displays the tree as a figure instead of text.
# ============================================================

Phylo.draw(tree)


# ============================================================
# 13. SCATTER PLOT: BIOFILM VS METABOLIC ACTIVITY
# Purpose:
# This plot shows the relation between total biofilm biomass
# measured by crystal violet and metabolic activity measured by XTT.
# ============================================================

plt.figure(figsize=(8, 6))
plt.scatter(df["biofilm_OD570"], df["metabolic_OD490"])

plt.xlabel("Biofilm biomass OD570")
plt.ylabel("Metabolic activity OD490")
plt.title("Biofilm Biomass vs Metabolic Activity")
plt.grid(True)

plt.show()


# ============================================================
# 14. SCATTER PLOT: CSH VS BIOFILM
# Purpose:
# This plot helps evaluate whether cell surface hydrophobicity
# is associated with biofilm formation.
# ============================================================

plt.figure(figsize=(8, 6))
plt.scatter(df["CSH_percent"], df["biofilm_OD570"])

plt.xlabel("Cell Surface Hydrophobicity (%)")
plt.ylabel("Biofilm biomass OD570")
plt.title("CSH vs Biofilm Formation")
plt.grid(True)

plt.show()


# ============================================================
# 15. BAR PLOT: VIRULENCE SCORE PER ISOLATE
# Purpose:
# This plot shows how many virulence genes are present in each isolate.
# ============================================================

plt.figure(figsize=(14, 6))
plt.bar(df["species"], df["virulence_score"])

plt.xticks(rotation=90)
plt.ylabel("Virulence score")
plt.title("Virulence Score per Candida Isolate")

plt.tight_layout()
plt.show()


# ============================================================
# 16. BAR PLOT: MEAN BIOFILM BY SPECIES
# Purpose:
# This plot compares the average biofilm production between species.
# ============================================================

plt.figure(figsize=(10, 6))
plt.bar(mean_by_species.index, mean_by_species["biofilm_OD570"])

plt.xticks(rotation=45, ha="right")
plt.ylabel("Mean biofilm OD570")
plt.title("Mean Biofilm Formation by Species")

plt.tight_layout()
plt.show()


# ============================================================
# 17. PIE CHART: BIOFILM LEVEL DISTRIBUTION
# Purpose:
# This plot shows the percentage of strong and weak biofilm producers.
# ============================================================

biofilm_counts = df["biofilm_level"].value_counts()

plt.figure(figsize=(6, 6))
plt.pie(
    biofilm_counts,
    labels=biofilm_counts.index,
    autopct="%1.1f%%"
)

plt.title("Distribution of Biofilm Levels")
plt.show()


# ============================================================
# 18. SAVE RESULTS TO NEW CSV FILE
# Purpose:
# We save the table after adding calculated columns.
# This file can be used later in Excel or for your report.
# ============================================================

df.to_csv("results_with_calculations.csv", index=False)

print("\n=== FILE SAVED ===")
print("Results saved as: results_with_calculations.csv")
