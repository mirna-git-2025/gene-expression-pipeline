# ============================================================
# PROJECT:
# DNA sequence analysis: GC content, RNA transcription,
# protein translation, motif search, ORF detection, and plots
# ============================================================

from Bio import SeqIO            # used to read sequences from FASTA files
from Bio.Seq import Seq         # used for sequence operations (translation, reverse complement)
import pandas as pd             # used to organize results in tables (DataFrame)
import matplotlib.pyplot as plt # used to create graphs


# =========================
# INPUT FILE
# =========================

# Name of the FASTA file containing the DNA sequences
fasta_file = "projectsequences.fasta"

# Motif to search inside the DNA sequence (ATG = start codon)
motif = "ATG"

# Empty list to store all computed results for each sequence
data = []


# =========================
# READ FASTA FILE
# =========================

for record in SeqIO.parse(fasta_file, "fasta"):  # loop through each sequence in the FASTA file

    seq_id = record.id                  # extract sequence ID/name
    dna = str(record.seq).upper()       # convert sequence to uppercase string

    length = len(dna)                   # calculate total sequence length

    # Count each nucleotide
    A = dna.count("A")                 # count Adenine
    T = dna.count("T")                 # count Thymine
    G = dna.count("G")                 # count Guanine
    C = dna.count("C")                 # count Cytosine

    # Calculate GC content (% of G and C in the sequence)
    gc = (G + C) / length * 100

    # Classify GC content into categories
    if gc < 40:
        gc_class = "Low GC"
    elif gc <= 60:
        gc_class = "Moderate GC"
    else:
        gc_class = "High GC"

    # Transcribe DNA to RNA (replace T with U)
    rna = dna.replace("T", "U")


    # =========================
    # FIX ADDED HERE
    # =========================

    # Calculate remainder when dividing length by 3
    # Translation requires codons (3 nucleotides)
    remainder = len(dna) % 3

    # If sequence length is not divisible by 3 → trim extra bases
    if remainder != 0:
        dna_trimmed = dna[:-remainder]   # remove last 1 or 2 nucleotides
    else:
        dna_trimmed = dna               # keep sequence unchanged

    # Translate trimmed DNA into protein
    # to_stop=True → stops translation at first stop codon
    protein = str(Seq(dna_trimmed).translate(to_stop=True))


    # Calculate protein length (number of amino acids)
    protein_length = len(protein)

    # Count how many times ATG motif appears
    motif_count = dna.count(motif)

    # Generate reverse complement (useful in molecular biology)
    reverse_complement = str(Seq(dna).reverse_complement())

    # Check if sequence starts with start codon ATG
    if dna.startswith("ATG"):
        start_codon = "Present"
    else:
        start_codon = "Absent"

    # Count stop codons (TAA, TAG, TGA)
    stop_codons = ["TAA", "TAG", "TGA"]
    stop_count = 0

    for stop in stop_codons:
        stop_count += dna.count(stop)   # count each stop codon occurrence

    # Simple ORF prediction
    # ORF = region that can code for a protein
    if dna.startswith("ATG") and stop_count > 0:
        orf_status = "Possible complete ORF"
    elif dna.startswith("ATG") and stop_count == 0:
        orf_status = "Start codon only"
    else:
        orf_status = "No clear ORF"

    # Calculate AT content (% of A and T)
    at = (A + T) / length * 100

    # Store all computed values into the list
    data.append([
        seq_id,
        length,
        A,
        T,
        G,
        C,
        round(gc, 2),
        round(at, 2),
        gc_class,
        motif_count,
        start_codon,
        stop_count,
        orf_status,
        protein_length,
        protein,
        rna,
        reverse_complement
    ])


# =========================
# CREATE DATAFRAME
# =========================

# Convert results list into a structured table
df = pd.DataFrame(data, columns=[
    "ID",
    "Length",
    "A_count",
    "T_count",
    "G_count",
    "C_count",
    "GC%",
    "AT%",
    "GC_class",
    "ATG_motif_count",
    "Start_codon",
    "Stop_codon_count",
    "ORF_status",
    "Protein_length",
    "Protein_sequence",
    "RNA_sequence",
    "Reverse_complement"
])

print("\n🧾 Complete Results:")
print(df)


# =========================
# N50 CALCULATION
# =========================

def calculate_n50(lengths):
    lengths = sorted(lengths, reverse=True)  # sort lengths from longest to shortest
    total = sum(lengths)                     # total genome size
    cumulative = 0

    for length in lengths:
        cumulative += length                # accumulate lengths
        if cumulative >= total / 2:         # stop when reaching 50%
            return length                   # this value is N50


n50 = calculate_n50(df["Length"])
print("\n📊 N50 value:", n50)


# =========================
# SUMMARY STATISTICS
# =========================

print("\n📌 Summary Statistics:")
print("Number of sequences:", len(df))                        # total sequences
print("Mean sequence length:", round(df["Length"].mean(), 2)) # average length
print("Mean GC%:", round(df["GC%"].mean(), 2))               # average GC
print("Mean AT%:", round(df["AT%"].mean(), 2))               # average AT
print("Longest sequence:", df.loc[df["Length"].idxmax(), "ID"])  # longest seq
print("Shortest sequence:", df.loc[df["Length"].idxmin(), "ID"]) # shortest seq


# =========================
# SAVE RESULTS
# =========================

df.to_csv("projectsequences_results.csv", index=False)  # save results to CSV file
print("\n✅ Results saved as: projectsequences_results.csv")


# =========================
# FIGURE 1: LENGTH DISTRIBUTION
# =========================

plt.figure(figsize=(7, 4))
plt.hist(df["Length"], bins=10, edgecolor="black")  # histogram of lengths
plt.title("Sequence Length Distribution")
plt.xlabel("Sequence Length")
plt.ylabel("Number of Sequences")
plt.tight_layout()
plt.show()


# =========================
# FIGURE 2: GC TREND
# =========================

plt.figure(figsize=(10, 5))
plt.plot(df["ID"], df["GC%"], marker="o", linestyle="-")  # line plot of GC%
plt.title("GC Content Trend Across Sequences")
plt.xlabel("Sequence ID")
plt.ylabel("GC Content (%)")
plt.xticks(rotation=45, ha="right")
plt.ylim(0, 100)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()


# =========================
# FIGURE 3: LENGTH vs GC
# =========================

plt.figure(figsize=(6, 4))
plt.scatter(df["Length"], df["GC%"])  # scatter plot
plt.title("Length vs GC Content")
plt.xlabel("Sequence Length")
plt.ylabel("GC Content (%)")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()


# =========================
# FIGURE 4: TOP 5 LONGEST
# =========================

top5 = df.sort_values(by="Length", ascending=False).head(5)  # select top 5

plt.figure(figsize=(7, 4))
plt.bar(top5["ID"], top5["Length"])  # bar plot
plt.title("Top 5 Longest Sequences")
plt.xlabel("Sequence ID")
plt.ylabel("Sequence Length")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.show()


# =========================
# FIGURE 5: GC CLASS
# =========================

gc_counts = df["GC_class"].value_counts()  # count GC classes

plt.figure(figsize=(6, 6))
plt.pie(gc_counts, labels=gc_counts.index, autopct="%1.1f%%")  # pie chart
plt.title("Distribution of GC Classes")
plt.tight_layout()
plt.show()


# =========================
# FIGURE 6: MOTIF COUNT
# =========================

plt.figure(figsize=(8, 4))
plt.bar(df["ID"], df["ATG_motif_count"])  # bar plot of ATG count
plt.title("ATG Motif Count per Sequence")
plt.xlabel("Sequence ID")
plt.ylabel("ATG Count")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.show()


print("\n🎉 Analysis complete.")
