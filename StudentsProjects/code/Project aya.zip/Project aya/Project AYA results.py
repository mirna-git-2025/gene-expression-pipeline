Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.

================ RESTART: C:\Users\Admin\Desktop\AYA project.py ================
Index(['sample_id', 'treatment', 'cell_line', 'dose_ug_ml', 'extracellular_ph',
       '5fu_dose_um', 'cell_viability_percent', 'ros_fold_change',
       'apoptosis_percent', 'lactate_mm'],
      dtype='str')

=== LACTATE REDUCTION ===
                      treatment  lactate_reduction_percent
0                       Control                   0.000000
1                      5FU_only                  12.432432
2                 Hummus_Tahini                  20.000000
3             Hummus_Tahini+5FU                  50.270270
4         Sesame_Polysaccharide                  27.027027
5     Sesame_Polysaccharide+5FU                  52.972973
6       Chickpea_Polysaccharide                  23.783784
7   Chickpea_Polysaccharide+5FU                  47.027027
8           Mloukhiyeh+VitaminC                  38.378378
9       Mloukhiyeh+VitaminC+5FU                  59.459459
10            Khoubaizeh+Tahini                  33.513514
11        Khoubaizeh+Tahini+5FU                  56.216216

=== APOPTOSIS INCREASE ===
                      treatment  apoptosis_increase
0                       Control                   0
1                      5FU_only                  23
2                 Hummus_Tahini                  17
3             Hummus_Tahini+5FU                  49
4         Sesame_Polysaccharide                  21
5     Sesame_Polysaccharide+5FU                  54
6       Chickpea_Polysaccharide                  19
7   Chickpea_Polysaccharide+5FU                  46
8           Mloukhiyeh+VitaminC                  32
9       Mloukhiyeh+VitaminC+5FU                  63
10            Khoubaizeh+Tahini                  28
11        Khoubaizeh+Tahini+5FU                  58

=== BEST TREATMENT ===
sample_id                                        T10
treatment                    Mloukhiyeh+VitaminC+5FU
cell_line                                      Caco2
dose_ug_ml                                       200
extracellular_ph                                 7.4
5fu_dose_um                                       10
cell_viability_percent                            27
ros_fold_change                                  3.8
apoptosis_percent                                 68
lactate_mm                                       7.5
lactate_reduction_percent                  59.459459
apoptosis_increase                                63
Name: 9, dtype: object

=== GENES ===
LDHA ATGGCTAACGTTAGCTAACGTAGCT
GLUT1 ATGCGTAACCGTAGCTAGCTAACGA
HIF1A ATGTTAGCGATCGTAGCTAAGCTAA
MCT4 ATGCGATAGCTAGCTAACGTAGCAA
BAX ATGCTAGCTAACGTAGCTAACGTAA
BCL2 ATGCGTAGCTAACGTTAGCGATCAA
CASP3 ATGTTAACGTAGCTAACGTAGCTTA
TP53 ATGCGTAACGTTAGCTAACGATGCA
VEGFA ATGCTAACGTAGCTAACGTAGGTAA
AKT1 ATGCGTAACGTAGCTAACGTTAGCA

Sequence lengths:
LDHA 25
GLUT1 25
HIF1A 25
MCT4 25
BAX 25
BCL2 25
CASP3 25
TP53 25
VEGFA 25
AKT1 25

=== DISTANCE MATRIX ===
LDHA    0.000000
GLUT1   0.400000    0.000000
HIF1A   0.840000    0.840000    0.000000
MCT4    0.760000    0.520000    0.640000    0.000000
BAX 0.880000    0.800000    0.200000    0.640000    0.000000
BCL2    0.560000    0.360000    0.800000    0.520000    0.720000    0.000000
CASP3   0.840000    0.760000    0.360000    0.720000    0.480000    0.640000    0.000000
TP53    0.200000    0.280000    0.800000    0.600000    0.800000    0.360000    0.800000    0.000000
VEGFA   0.840000    0.720000    0.400000    0.600000    0.360000    0.560000    0.120000    0.760000    0.000000
AKT1    0.440000    0.480000    0.760000    0.320000    0.760000    0.520000    0.760000    0.400000    0.720000    0.000000
    LDHA    GLUT1   HIF1A   MCT4    BAX BCL2    CASP3   TP53    VEGFA   AKT1

=== PHYLOGENETIC TREE ===
                       ____ TP53
          ____________|
  _______|            |__________________ LDHA
 |       |
 |       |_______________ GLUT1
 |
 |                  _______________ AKT1
 |         ________|
 |        |        |______________________ MCT4
 |        |
_|________|                                               ____ VEGFA
 |        |                                 _____________|
 |        |                                |             |__________ CASP3
 |        |________________________________|
 |                                         |               ____________ BAX
 |                                         |______________|
 |                                                        |___________ HIF1A
 |
 |____________________ BCL2

Traceback (most recent call last):
  File "C:\Users\Admin\AppData\Local\Python\pythoncore-3.14-64\Lib\site-packages\pandas\core\indexes\base.py", line 3641, in get_loc
    return self._engine.get_loc(casted_key)
  File "pandas/_libs/index.pyx", line 168, in pandas._libs.index.IndexEngine.get_loc
  File "pandas/_libs/index.pyx", line 197, in pandas._libs.index.IndexEngine.get_loc
  File "pandas/_libs/hashtable_class_helper.pxi", line 7668, in pandas._libs.hashtable.PyObjectHashTable.get_item
  File "pandas/_libs/hashtable_class_helper.pxi", line 7676, in pandas._libs.hashtable.PyObjectHashTable.get_item
KeyError: 'extracellular_pH'

The above exception was the direct cause of the following exception:

Traceback (most recent call last):
  File "C:\Users\Admin\Desktop\AYA project.py", line 169, in <module>
    plt.scatter(df["extracellular_pH"], df["cell_viability_percent"], color="red")
  File "C:\Users\Admin\AppData\Local\Python\pythoncore-3.14-64\Lib\site-packages\pandas\core\frame.py", line 4378, in __getitem__
    indexer = self.columns.get_loc(key)
  File "C:\Users\Admin\AppData\Local\Python\pythoncore-3.14-64\Lib\site-packages\pandas\core\indexes\base.py", line 3648, in get_loc
    raise KeyError(key) from err
KeyError: 'extracellular_pH'
