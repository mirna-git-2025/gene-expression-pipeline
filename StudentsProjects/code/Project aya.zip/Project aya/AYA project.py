import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from Bio import SeqIO
from Bio.Align import MultipleSeqAlignment
from Bio.Phylo.TreeConstruction import DistanceCalculator, DistanceTreeConstructor
from Bio import Phylo
df = pd.read_csv("ndata.csv")

# remove spaces + lowercase + replace spaces with underscores
df.columns = (
    df.columns
    .str.strip()
    .str.lower()
    .str.replace(" ", "_")
)

print(df.columns)
# ==========================================
# 2. CALCULATE LACTATE REDUCTION
# ==========================================

control_lactate = df[df["treatment"] == "Control"]["lactate_mm"].values[0]

df["lactate_reduction_percent"] = (
    (control_lactate - df["lactate_mm"]) / control_lactate
) * 100

print("\n=== LACTATE REDUCTION ===")
print(df[["treatment", "lactate_reduction_percent"]])
# ==========================================
# 3. CALCULATE APOPTOSIS INCREASE
# ==========================================

control_apoptosis = df[df["treatment"] == "Control"]["apoptosis_percent"].values[0]

df["apoptosis_increase"] = (
    df["apoptosis_percent"] - control_apoptosis
)

print("\n=== APOPTOSIS INCREASE ===")
print(df[["treatment", "apoptosis_increase"]])
# ==========================================
# 4. BEST TREATMENT
# ==========================================

best = df.loc[df["cell_viability_percent"].idxmin()]

print("\n=== BEST TREATMENT ===")
print(best)

# ==========================================
# 5. LOAD FASTA FILE
# ==========================================

records = list(SeqIO.parse("geness.fasta", "fasta"))

print("\n=== GENES ===")
for r in records:
    print(r.id, r.seq)
print("\nSequence lengths:")
for r in records:
    print(r.id, len(r.seq))
# ==========================================
# 6. ALIGNMENT
# ==========================================

alignment = MultipleSeqAlignment(records)

# ==========================================
# 7. DISTANCE MATRIX
# ==========================================

calculator = DistanceCalculator("identity")
dm = calculator.get_distance(alignment)

print("\n=== DISTANCE MATRIX ===")
print(dm)

# ==========================================
# 8. PHYLOGENETIC TREE
# ==========================================

constructor = DistanceTreeConstructor()
tree = constructor.nj(dm)

print("\n=== PHYLOGENETIC TREE ===")
Phylo.draw_ascii(tree)

Phylo.draw(tree)
import matplotlib.pyplot as plt

# ==========================================
# 9. pH vs VIABILITY
# ==========================================

plt.figure(figsize=(8,5))
plt.scatter(
    df["extracellular_ph"],
    df["cell_viability_percent"],
    color="red"
)

for i in range(len(df)):
    plt.text(
        df["extracellular_ph"][i],
        df["cell_viability_percent"][i],
        df["sample_id"][i]
    )

plt.xlabel("Extracellular pH")
plt.ylabel("Cell Viability (%)")
plt.title("pH vs Cell Viability")
plt.grid(True)
plt.show()

# ==========================================
# 10. ROS vs APOPTOSIS
# ==========================================

plt.figure(figsize=(8,5))
plt.scatter(
    df["ros_fold_change"],
    df["apoptosis_percent"],
    color="green"
)

plt.xlabel("ROS Fold Change")
plt.ylabel("Apoptosis (%)")
plt.title("ROS vs Apoptosis")
plt.grid(True)
plt.show()

# ==========================================
# 11. LACTATE COMPARISON
# ==========================================

plt.figure(figsize=(10,5))
plt.bar(
    df["treatment"],
    df["lactate_mm"],
    color="orange"
)

plt.xticks(rotation=45, ha="right")
plt.ylabel("Lactate (mM)")
plt.title("Lactate Production by Treatment")
plt.tight_layout()
plt.show()

# ==========================================
# 12. VIABILITY COMPARISON
# ==========================================

plt.figure(figsize=(10,5))
plt.bar(
    df["treatment"],
    df["cell_viability_percent"],
    color="blue"
)

plt.xticks(rotation=45, ha="right")
plt.ylabel("Cell Viability (%)")
plt.title("Treatment Effect on CRC Viability")
plt.tight_layout()
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(df["extracellular_pH"], df["cell_viability_percent"], color="red")

for i in range(len(df)):
    plt.text(df["extracellular_pH"][i], df["cell_viability_percent"][i], df["sample_id"][i])

plt.xlabel("Extracellular pH")
plt.ylabel("Cell Viability (%)")
plt.title("pH vs Cell Viability")
plt.grid(True)
plt.show()
print(df.head())

