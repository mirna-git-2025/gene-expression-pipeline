Python 3.11.9 (tags/v3.11.9:de54cf5, Apr  2 2024, 10:12:12) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

========================================================== RESTART: C:/Users/hp/Downloads/datsresults.py ==========================================================

=== METADATA ===
               species   host   region  year  ct_value sample_type
0  Brucella_melitensis  human    Akkar  2023      22.5       blood
1     Brucella_abortus    cow  Tripoli  2022      28.1        milk
2  Brucella_melitensis   goat    Akkar  2023      20.3      cheese
3     Brucella_abortus  human  Tripoli  2021      30.0       blood
4  Brucella_melitensis   goat  Miniyeh  2022      18.9        milk
5     Brucella_abortus    cow    Akkar  2023      27.4        milk
6  Brucella_melitensis  human  Tripoli  2022      21.7       blood
7     Brucella_abortus   goat  Miniyeh  2021      29.5      cheese
8  Brucella_melitensis   goat    Akkar  2023      19.8        milk
9     Brucella_abortus  human  Tripoli  2022      31.2       blood

=== BACTERIAL LOAD ===
               species  bacterial_load
0  Brucella_melitensis        0.044444
1     Brucella_abortus        0.035587
2  Brucella_melitensis        0.049261
3     Brucella_abortus        0.033333
4  Brucella_melitensis        0.052910
5     Brucella_abortus        0.036496
6  Brucella_melitensis        0.046083
7     Brucella_abortus        0.033898
8  Brucella_melitensis        0.050505
9     Brucella_abortus        0.032051

=== MEAN Ct PER SPECIES ===
species
Brucella_abortus       29.24
Brucella_melitensis    20.64
Name: ct_value, dtype: float64

=== CASES PER HOST ===
host
human    4
goat     4
cow      2
Name: count, dtype: int64

=== RAW SEQUENCES ===
Brucella_melitensis_1 ATGCTAGCTAGCTACGATCGATCGATCG
Brucella_abortus_1 ATGCTAGCTAGTTACGATCGATCGATCG
Brucella_melitensis_2 ATGCTAGCTAGCTACGATCGATCGATCA
Brucella_abortus_2 ATGCTAGCTAGTTACGATCGATCGATCA

=== ALIGNMENT LENGTH ===
28

=== DISTANCE MATRIX ===
Brucella_melitensis_1   0.000000
Brucella_abortus_1  0.035714    0.000000
Brucella_melitensis_2   0.035714    0.071429    0.000000
Brucella_abortus_2  0.071429    0.035714    0.035714    0.000000
    Brucella_melitensis_1   Brucella_abortus_1  Brucella_melitensis_2   Brucella_abortus_2

=== PHYLOGENETIC TREE (ASCII) ===
                              ___________________________ Brucella_melitensis_1
  ___________________________|
 |                           |___________________________ Brucella_abortus_1
_|
 |___________________________ Brucella_melitensis_2
 |
 |___________________________ Brucella_abortus_2

