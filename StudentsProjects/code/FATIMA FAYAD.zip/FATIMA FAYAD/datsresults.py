# ==============================
# IMPORT LIBRARIES
# ==============================

import pandas as pd
import matplotlib.pyplot as plt

from Bio import SeqIO
from Bio.Align import MultipleSeqAlignment
from Bio.Phylo.TreeConstruction import DistanceCalculator, DistanceTreeConstructor
from Bio import Phylo

# ==============================
# 1. LOAD METADATA (CSV)
# ==============================

df = pd.read_csv("datas.csv")

# Clean column names
df.columns = df.columns.str.strip().str.lower()

print("\n=== METADATA ===")
print(df)

# ==============================
# 2. CREATE BIOLOGICAL METRIC
# (Bacterial load proxy from Ct)
# ==============================

df["bacterial_load"] = 1 / df["ct_value"]

print("\n=== BACTERIAL LOAD ===")
print(df[["species", "bacterial_load"]])

# ==============================
# 3. BASIC STATISTICS
# ==============================

print("\n=== MEAN Ct PER SPECIES ===")
print(df.groupby("species")["ct_value"].mean())

print("\n=== CASES PER HOST ===")
print(df["host"].value_counts())

# ==============================
# 4. LOAD FASTA SEQUENCES
# ==============================

records = list(SeqIO.parse("sequenceforpython.fasta", "fasta"))

print("\n=== RAW SEQUENCES ===")
for r in records:
    print(r.id, r.seq)

# ==============================
# 5. MULTIPLE SEQUENCE ALIGNMENT
# (Assumes sequences already aligned)
# ==============================

alignment = MultipleSeqAlignment(records)

print("\n=== ALIGNMENT LENGTH ===")
print(alignment.get_alignment_length())

# ==============================
# 6. DISTANCE MATRIX (IDENTITY)
# ==============================

calculator = DistanceCalculator("identity")
dm = calculator.get_distance(alignment)

print("\n=== DISTANCE MATRIX ===")
print(dm)

# ==============================
# 7. PHYLOGENETIC TREE (NJ)
# ==============================

constructor = DistanceTreeConstructor()
tree = constructor.nj(dm)

print("\n=== PHYLOGENETIC TREE (ASCII) ===")
Phylo.draw_ascii(tree)

# ==============================
# 8. GRAPHICAL TREE
# ==============================

Phylo.draw(tree)

# ==============================
# 9. BAR CHART (MEAN Ct PER SPECIES)
# ==============================

plt.figure(figsize=(8, 5))

df.groupby("species")["ct_value"].mean().plot(kind="bar")

plt.ylabel("Mean Ct Value")
plt.title("Ct Values per Species")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ==============================
# 10. SCATTER PLOT (YEAR vs Ct)
# ==============================

plt.figure(figsize=(8, 5))

plt.scatter(df["year"], df["ct_value"])

for i in range(len(df)):
    plt.text(df["year"][i], df["ct_value"][i], df["species"][i])

plt.xlabel("Year")
plt.ylabel("Ct Value")
plt.title("Ct Evolution Over Time")
plt.grid(True)
plt.show()

# ==============================
# 11. PIE CHART (HOST DISTRIBUTION)
# ==============================

plt.figure(figsize=(6, 6))

df["host"].value_counts().plot(kind="pie", autopct="%1.1f%%")

plt.title("Host Distribution")
plt.ylabel("")
plt.show()
# ==============================
# 9. BAR CHART (MEAN Ct PER SPECIES)
# ==============================

plt.figure(figsize=(8, 5))

df.groupby("species")["ct_value"].mean().plot(kind="bar")

plt.ylabel("Mean Ct Value")
plt.title("Ct Values per Species")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# ==============================
# 10. SCATTER PLOT (YEAR vs Ct)
# ==============================

plt.figure(figsize=(8, 5))

plt.scatter(df["year"], df["ct_value"])

for i in range(len(df)):
    plt.text(df["year"][i], df["ct_value"][i], df["species"][i])

plt.xlabel("Year")
plt.ylabel("Ct Value")
plt.title("Ct Evolution Over Time")
plt.grid(True)
plt.show()


# ==============================
# 11. PIE CHART (HOST DISTRIBUTION)
# ==============================

plt.figure(figsize=(6, 6))

df["host"].value_counts().plot(kind="pie", autopct="%1.1f%%")

plt.title("Host Distribution")
plt.ylabel("")
plt.show()


# ==============================
# 12. BOXPLOT (Ct DISTRIBUTION PER SPECIES)
# ==============================

plt.figure(figsize=(8, 5))

df.boxplot(column="ct_value", by="species")

plt.title("Ct Value Distribution per Species")
plt.suptitle("")  # remove automatic pandas title
plt.xlabel("Species")
plt.ylabel("Ct Value")

plt.grid(True)
plt.show()
